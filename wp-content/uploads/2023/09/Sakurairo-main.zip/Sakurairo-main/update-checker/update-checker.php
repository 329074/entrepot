<?php
/**
 * Plugin Update Checker Library 5.1
 * http://w-shadow.com/
 *
 * Copyright 2023 Janis Elsts
 * Released under the MIT license. See license.txt for details.
 */

require dirname(__FILE__) . '/load-v5p1.php';